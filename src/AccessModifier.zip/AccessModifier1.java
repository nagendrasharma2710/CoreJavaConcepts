package Package1;

public class AccessModifier1 {

	 int n = 4;
	 int m = 6;

	public int getN() {
		return n;
	}
	public void setN(int n) {
		this.n = n;
	}
	public int getM() {
		return m;
	}
	public void setM(int m) {
		this.m = m;
	}
}
