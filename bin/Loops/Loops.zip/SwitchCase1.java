package Loops;

public class SwitchCase1 {
	public static void main(String []args) {
		String str = "dive";

		switch(str) {
		case "add":
			System.out.println("MyToshika");
			break;
		case "sub":
			System.out.println("MyToshika It solution");
			break;
		case "pro":
			System.out.println("MyToshika It Solution, Noida");
			break;
		case "div":	
			System.out.println("MyToshika It Solution, Greater Noida, India");
			break;
		default:
			System.out.println("InValid Request");
		}
	}
}
