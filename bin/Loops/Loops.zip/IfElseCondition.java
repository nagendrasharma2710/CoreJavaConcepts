package Loops;

public class IfElseCondition {
	public static void main(String []args) {
		int c = 5;
		int d = 7;
		
		if(c+d<16) {
			System.out.println("Given no. is greater than sum");
		}else {
			System.out.println("Given no. is less than sum");
		}
	}

}
