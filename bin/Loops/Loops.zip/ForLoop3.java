package Loops;

public class ForLoop3 {
	public static void main(String args[]) {
		int[] numbers = {3, 7, 2, -5, -4, 0};
		for (int num: numbers) {
			System.out.println(num);
		}
	
//	float[] numbers = {3.3, 2.7, 5.0};
	for (double num: numbers) {
		System.out.println(num);
	}
}
}

