package Loops;

public class IfElseIfCondition {
	public static void main(String []args) {
		String str = "MyToshika It Solution";

		if(str == "noida") {
			System.out.println("this is noida");
		}if (str == "delhi") {
			System.out.println("this is delhi");
		}if (str == "agra") {
			System.out.println("this is agra");
		}else {
			System.out.println(str);
		}
	}
}
