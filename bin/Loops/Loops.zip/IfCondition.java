package Loops;

public class IfCondition {
	public static void main(String []args) {
		int a = 4;
		int b = 6;
		if(a+b<12) {
			System.out.println(a+b);
		}
	}
}