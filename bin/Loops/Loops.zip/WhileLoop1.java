package Loops;

public class WhileLoop1 {
	public static void main(String []args) {
		int i =5; 

		while(i<=50) {    
			System.out.println(i);    
			i = i + 5;  
		}
	}
}	